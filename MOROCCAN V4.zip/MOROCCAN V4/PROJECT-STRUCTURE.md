# 🏗️ PROJECT STRUCTURE & ARCHITECTURE OVERVIEW

## 📁 **CURRENT PROJECT STRUCTURE**

```
الشارع المغربي - AI Course Platform/
├── 📄 index.html                    # 🏠 Main landing page - AI Video Course
├── 📄 dashboard.html                # 📊 User dashboard with course access
├── 📄 login.html                    # 🔐 Secure authentication page
├── 📄 validate.html                 # ✅ Email validation page
├── 📄 integration-test.html         # 🧪 Integration testing page
├── 📄 blog-template.html            # 📝 Blog template (future use)
├── 📄 test-*.html                   # 🔬 Various test pages
├── 📄 request.json                  # 📋 API request configurations
├── 📄 tools-data.json               # 🛠️ Tools database
├── 📄 texta.txt                     # 📚 Text data for prompts
├── 📄 test.txt                      # 📄 Test data file
│
├── 📁 css/                          # 🎨 Styling Architecture
│   ├── 📄 global.css                # ✅ MAIN - Unified styles (1,414 lines)
│   ├── 📄 forms.css                 # 📝 Form-specific styles
│   ├── 📄 timeline.css              # ⏰ Timeline component styles
│   └── 📄 tools.css                 # 🛠️ Tools-specific styles
│
├── 📁 js/                           # ⚡ JavaScript Architecture
│   ├── 📄 auth.js                   # 🔐 Authentication manager (181 lines)
│   ├── 📄 config.js                 # ⚙️ API configuration
│   ├── 📄 env-config.js             # 🌍 Environment variables
│   ├── 📄 header.js                 # 🧭 Header component
│   ├── 📄 footer.js                 # 🦶 Footer component
│   ├── 📄 shared-components.js      # 🔄 Reusable components
│   ├── 📄 chat.js                   # 💬 Chat functionality
│   ├── 📄 common.js                 # 🔧 Shared utilities
│   ├── 📄 index.js                  # 🏠 Main page logic
│   ├── 📄 login.js                  # 🔐 Login functionality
│   ├── 📄 protection.js             # 🛡️ Route protection
│   ├── 📄 error-handler.js          # ❌ Error handling
│   ├── 📄 hcaptcha.js               # 🤖 Captcha integration
│   ├── 📄 path-config.js            # 🗺️ Path configurations
│   └── 📄 tools-data.js             # 🛠️ Tools data management
│
├── 📁 assets/                       # 🖼️ Media Assets
│   ├── 📁 images/                   # 🖼️ Main images
│   │   ├── 📄 logo.svg              # 🏷️ Brand logo
│   │   ├── 📄 halo.webp             # ✨ Hero background
│   │   ├── 📄 herosection.webp      # 🎯 Hero section image
│   │   ├── 📄 course-screenshot.png # 📸 Course preview
│   │   ├── 📄 course-placeholder.svg# 📋 Course placeholder
│   │   ├── 📄 testimonial-placeholder.svg # 💬 Testimonial placeholder
│   │   └── 📄 Untitled.webp         # 🖼️ Additional image
│   └── 📁 logos/                    # 🏷️ Logo variants
│       └── 📄 default.svg           # 🏷️ Default logo
│
├── 📁 pages/                        # 📄 Organized Page Structure
│   ├── 📁 tools/                    # 🛠️ AI Tools Suite
│   │   ├── 📄 AIStyleBank.html      # 🎨 AI Art Styles Bank (961 lines)
│   │   ├── 📄 backprompt.html       # 💬 Prompts Library (745 lines)
│   │   ├── 📄 AIToolsDirectory.html # 📚 Tools Directory (1,144 lines)
│   │   ├── 📄 Aicoursevideos.html   # 🎥 Course Videos (1,700 lines)
│   │   ├── 📄 exercices.html        # 📝 Practice exercises
│   │   ├── 📄 premium-course-details.html # 💎 Premium course info
│   │   ├── 📄 content-loader.js     # 📥 Dynamic content loading
│   │   ├── 📄 protection.js         # 🛡️ Page protection
│   │   └── 📁 assets/               # 🖼️ Tools-specific assets
│   │       └── 📁 logos/
│   │           └── 📄 default.svg
│   │
│   ├── 📁 forms/                    # 📝 Form Pages
│   │   ├── 📄 AIform.html           # 🤖 AI form interface
│   │   └── 📄 coursedetailes.html   # 📋 Course details form
│   │
│   └── 📁 legal/                    # ⚖️ Legal Pages
│       ├── 📄 privacy.html          # 🔒 Privacy policy
│       ├── 📄 terms.html            # 📜 Terms of service
│       └── 📄 refund.html           # 💰 Refund policy
│
└── 📄 Documentation Files           # 📚 Project Documentation
    ├── 📄 README.md                 # 📖 Main documentation
    ├── 📄 SETUP.md                  # ⚙️ Setup instructions
    ├── 📄 GOOGLE-OAUTH-SETUP.md     # 🔐 OAuth configuration
    ├── 📄 HCAPTCHA-MIGRATION-GUIDE.md # 🤖 Captcha setup
    └── 📄 INTEGRATION-COMPLETE.md   # ✅ Integration status
```

## 🎯 **PLATFORM OVERVIEW**

### **🏢 Platform Identity**
- **Name**: الشارع المغربي (Moroccan Street)
- **Focus**: AI Video Creation Course Platform
- **Language**: Arabic (RTL)
- **Target**: Content creators and AI enthusiasts

### **🔧 Core Technologies**
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: TailwindCSS + Custom CSS Variables
- **Authentication**: Supabase
- **Icons**: Lucide Icons
- **Fonts**: Tajawal (Arabic), Inter (Latin)
- **Captcha**: hCaptcha

## 🚀 **MAIN FEATURES & PAGES**

### **🏠 Landing Page (index.html)**
- **Purpose**: Main course promotion and enrollment
- **Features**:
  - Hero section with course overview
  - Course curriculum display
  - Instructor information
  - Pricing plans
  - Student testimonials
  - Knowledge base section
  - Authentication integration

### **📊 Dashboard (dashboard.html)**
- **Purpose**: Student learning portal
- **Features**:
  - Course progress tracking
  - Video lessons access
  - Tools navigation
  - User profile management
  - Protected content access

### **🔐 Authentication System**
- **Login Page**: Secure OTP-based authentication
- **Protection**: Route-based access control
- **Integration**: Supabase backend
- **Features**: Email verification, session management

## 🛠️ **AI TOOLS SUITE**

### **🎨 AI Style Bank (AIStyleBank.html)**
- **Purpose**: Art styles library for AI image generation
- **Features**:
  - 2 main categories: General Styles & Artist Styles
  - Search and filter functionality
  - Copy-to-clipboard prompts
  - Responsive design
  - Multi-language support (Arabic/French)

### **💬 Prompts Library (backprompt.html)**
- **Purpose**: YouTube content creation prompts
- **Features**:
  - 6 categories: Text, Image, Video, Strategy, Optimization
  - 100+ ready-to-use prompts
  - Category filtering
  - Copy functionality
  - Search capabilities

### **📚 AI Tools Directory (AIToolsDirectory.html)**
- **Purpose**: Comprehensive AI tools catalog
- **Features**:
  - Tool categorization
  - Detailed reviews and ratings
  - Search and filter system
  - External links to tools
  - Regular updates

### **🎥 Course Videos (Aicoursevideos.html)**
- **Purpose**: Video lessons access portal
- **Features**:
  - 6 structured lessons
  - YouTube integration
  - Progress tracking
  - Protected content
  - Mobile-responsive player

## 🎨 **DESIGN SYSTEM**

### **🎨 Color Palette**
```css
--primary-dark: #0a0a0a        /* Main background */
--secondary-burgundy: #8B1538   /* Brand burgundy */
--accent-gold: #D4AF37          /* Gold accents */
--accent-orange: #FF6B35        /* Orange highlights */
--accent-mocha: #A0522D         /* Mocha brown */
```

### **✨ Visual Effects**
- **Glass Morphism**: Translucent cards with blur effects
- **Gradient Animations**: Dynamic color transitions
- **Floating Elements**: Subtle hover animations
- **Shadow System**: Layered depth effects
- **Responsive Design**: Mobile-first approach

### **🔤 Typography**
- **Arabic**: Tajawal (400, 500, 700, 800, 900)
- **Latin**: Inter (400, 500, 700, 800, 900)
- **Direction**: RTL support for Arabic content

## ⚡ **TECHNICAL ARCHITECTURE**

### **🔐 Authentication Flow**
1. **AuthManager Class**: Unified authentication interface
2. **Supabase Integration**: Backend authentication service
3. **OTP System**: Email-based verification
4. **Session Management**: Persistent login state
5. **Route Protection**: Page-level access control

### **🧩 Component System**
- **Header Component**: Dynamic navigation with auth state
- **Footer Component**: Consistent site footer
- **Shared Components**: Reusable UI elements
- **Protection Scripts**: Access control middleware

### **📱 Responsive Design**
- **Mobile-First**: Optimized for mobile devices
- **Breakpoints**: sm, md, lg, xl responsive breakpoints
- **Touch-Friendly**: Large buttons and touch targets
- **Performance**: Optimized loading and animations

## 📊 **CONTENT STATISTICS**

### **📄 Page Complexity**
- **AIToolsDirectory.html**: 1,144 lines (Most complex)
- **Aicoursevideos.html**: 1,700 lines (Largest)
- **AIStyleBank.html**: 961 lines
- **backprompt.html**: 745 lines
- **global.css**: 1,414 lines (Main stylesheet)
- **auth.js**: 181 lines (Core authentication)

### **🛠️ Tools Content**
- **AI Tools**: 50+ categorized tools
- **Prompts**: 100+ ready-to-use prompts
- **Art Styles**: 2 main categories with subcategories
- **Video Lessons**: 6 structured course modules

## 🔧 **DEVELOPMENT SETUP**

### **📋 Prerequisites**
- Modern web browser
- Local web server (http-server, Live Server, etc.)
- Supabase account for authentication
- hCaptcha account for bot protection

### **⚙️ Configuration Files**
- **env-config.js**: Environment variables
- **config.js**: API configurations
- **tools-data.json**: Tools database
- **request.json**: API request templates

### **🚀 Deployment**
- **Static Hosting**: Compatible with any static host
- **CDN Ready**: External dependencies via CDN
- **Environment**: Production/development configurations
- **Security**: Environment-based API keys

## 🎯 **FUTURE ENHANCEMENTS**

### **📈 Planned Features**
- **Blog System**: Content marketing platform
- **Advanced Analytics**: User behavior tracking
- **Mobile App**: Native mobile application
- **API Integration**: External AI service connections
- **Community Features**: User forums and discussions

### **🔧 Technical Improvements**
- **Build Process**: Webpack/Vite integration
- **Code Splitting**: Lazy loading implementation
- **PWA Features**: Offline functionality
- **Performance**: Image optimization and caching
- **Testing**: Automated testing suite

## 📚 **DOCUMENTATION STATUS**

- ✅ **Project Structure**: Complete and up-to-date
- ✅ **Setup Guide**: Available in SETUP.md
- ✅ **OAuth Setup**: Detailed in GOOGLE-OAUTH-SETUP.md
- ✅ **Captcha Guide**: Available in HCAPTCHA-MIGRATION-GUIDE.md
- ✅ **Integration Status**: Documented in INTEGRATION-COMPLETE.md

---

**🎉 PROJECT STATUS: FULLY FUNCTIONAL & PRODUCTION-READY**

*Last Updated: January 2025*
*Total Files: 50+ organized files*
*Total Lines of Code: 10,000+ lines*
*Platform Language: Arabic (RTL)*
*Target Audience: Arabic-speaking content creators*