// Page Protection for Tools Directory
class ToolsPageProtection {
    constructor() {
        this.init();
    }

    async init() {
        try {
            // Check if page is accessed from dashboard (protected mode)
            const referrer = document.referrer;
            const isDashboardAccess = referrer.includes('dashboard.html') || 
                                    sessionStorage.getItem('dashboardAccess') === 'true';
            
            // If accessed from dashboard, require authentication
            if (isDashboardAccess) {
                // Wait for auth manager to be available
                await this.waitForAuthManager();
                
                // Initialize auth manager
                await window.authManager.init();
                
                // Check authentication
                const isAuthenticated = await window.authManager.isAuthenticated();
                
                if (!isAuthenticated) {
                    this.redirectToLogin();
                    return;
                }
                
                // Listen for auth state changes
                window.authManager.onAuthStateChange((event, session) => {
                    if (event === 'SIGNED_OUT' || !session) {
                        this.redirectToLogin();
                    }
                });
                
                console.log('Tools page protection initialized - user is authenticated');
                
                // Load secure content if function exists
                if (typeof window.loadSecureContent === 'function') {
                    window.loadSecureContent();
                }
            } else {
                // Public access from index.html - no authentication required
                console.log('Tools page accessed publicly - no authentication required');
                
                // Still try to initialize auth manager for potential features
                try {
                    await this.waitForAuthManager();
                    await window.authManager.init();
                } catch (error) {
                    console.log('Auth manager not available in public mode - continuing without authentication');
                }
            }
            
        } catch (error) {
            console.error('Error initializing tools page protection:', error);
            // In case of error, allow public access if not from dashboard
            const referrer = document.referrer;
            const isDashboardAccess = referrer.includes('dashboard.html') || 
                                    sessionStorage.getItem('dashboardAccess') === 'true';
            if (isDashboardAccess) {
                this.redirectToLogin();
            }
        }
    }

    // Wait for auth manager to be available
    async waitForAuthManager() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 50;
            
            const checkAuthManager = () => {
                if (typeof window !== 'undefined' && window.authManager) {
                    resolve();
                } else if (attempts >= maxAttempts) {
                    reject(new Error('AuthManager not available after maximum attempts'));
                } else {
                    attempts++;
                    setTimeout(checkAuthManager, 100);
                }
            };
            
            checkAuthManager();
        });
    }

    redirectToLogin() {
        const currentPath = window.location.pathname;
        const currentUrl = window.location.href;
        
        // Don't redirect if already on login page
        if (currentPath.includes('login.html')) {
            return;
        }
        
        console.log('User not authenticated, redirecting to login');
        
        // Redirect to root login with return URL
        const loginUrl = new URL('/login.html', window.location.origin);
        loginUrl.searchParams.set('redirect', currentUrl);
        
        window.location.href = loginUrl.toString();
    }
}

// Auto-protect the current page
document.addEventListener('DOMContentLoaded', () => {
    new ToolsPageProtection();
});

// Export for ES6 modules
export default ToolsPageProtection;

// Make it available globally
if (typeof window !== 'undefined') {
    window.ToolsPageProtection = ToolsPageProtection;
}

// Basic content protection
document.addEventListener('contextmenu', event => event.preventDefault());
document.addEventListener('keydown', event => {
    if (event.keyCode === 123 || 
        (event.ctrlKey && event.shiftKey && (event.keyCode === 73 || event.keyCode === 67 || event.keyCode === 74)) || 
        (event.ctrlKey && event.keyCode === 85)) {
        event.preventDefault();
    }
});