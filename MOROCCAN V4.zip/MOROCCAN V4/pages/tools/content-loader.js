// Secure Content Loader - Only loads after authentication verification
// This script contains all video data and dynamically builds the content

// Video data structure - contains all sensitive content
const videoData = [
    {
        id: "MVAFhtdShvE",
        url: "https://youtu.be/MVAFhtdShvE",
        embedId: "MVAFhtdShvE",
        lessonKey: "lesson1"
    },
    {
        id: "Cy5yH8QBzAU",
        url: "https://youtu.be/Cy5yH8QBzAU",
        embedId: "Cy5yH8QBzAU",
        lessonKey: "lesson2"
    },
    {
        id: "vjM1eF4HsEc",
        url: "https://youtu.be/vjM1eF4HsEc",
        embedId: "vjM1eF4HsEc",
        lessonKey: "lesson3"
    },
    {
        id: "WoVZ0GZv_2c",
        url: "https://youtu.be/WoVZ0GZv_2c",
        embedId: "WoVZ0GZv_2c",
        lessonKey: "lesson4"
    },
    {
        id: "amt6fIK5hh0",
        url: "https://youtu.be/amt6fIK5hh0",
        embedId: "amt6fIK5hh0",
        lessonKey: "lesson5"
    },
    {
        id: "HkI_nJJmKsg",
        url: "https://youtu.be/HkI_nJJmKsg",
        embedId: "HkI_nJJmKsg",
        lessonKey: "lesson6"
    },
    {
        id: "oIdcYqsh7Mc",
        url: "https://youtu.be/oIdcYqsh7Mc",
        embedId: "oIdcYqsh7Mc",
        lessonKey: "lesson7"
    },
    {
        id: "RdtFjoSwTek",
        url: "https://youtu.be/RdtFjoSwTek",
        embedId: "RdtFjoSwTek",
        lessonKey: "lesson8"
    },
    {
        id: "BYt6A3e3QdE",
        url: "https://youtu.be/BYt6A3e3QdE",
        embedId: "BYt6A3e3QdE",
        lessonKey: "lesson9"
    },
    {
        id: "uXoh_34a2uA",
        url: "https://youtu.be/uXoh_34a2uA",
        embedId: "uXoh_34a2uA",
        lessonKey: "lesson10"
    }
];

// Function to create a video card element
function createVideoCard(video) {
    return `
        <div class="video-card rounded-xl p-6 flex flex-col justify-between cursor-pointer hover:scale-105 transition-all duration-300" data-video-id="${video.id}" data-video-url="${video.url}" data-lesson-key="${video.lessonKey}">
            <div>
                <h2 class="text-2xl font-bold text-white mb-4" data-lang-key="${video.lessonKey}"></h2>
                <div class="video-container bg-black relative group">
                    <iframe src="https://www.youtube.com/embed/${video.embedId}" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <i data-lucide="maximize" class="w-12 h-12 text-white"></i>
                    </div>
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="${video.url}" target="_blank" rel="noopener noreferrer" class="btn-primary inline-flex items-center gap-3 px-6 py-3 text-white font-bold text-base rounded-xl transition-all duration-500">
                    <i data-lucide="external-link" class="w-5 h-5 relative z-10"></i>
                    <span data-lang-key="watchOnYouTube" class="relative z-10">مشاهدة على يوتيوب</span>
                </a>
            </div>
        </div>
    `;
}

// Function to load all video content into the page
function loadVideoContent() {
    console.log('Loading secure video content...');
    
    // Find the grid container
    const gridContainer = document.querySelector('#all-lessons .grid');
    
    if (!gridContainer) {
        console.error('Grid container not found!');
        return;
    }
    
    // Clear any existing content
    gridContainer.innerHTML = '';
    
    // Generate and insert all video cards
    videoData.forEach(video => {
        gridContainer.innerHTML += createVideoCard(video);
    });
    
    console.log(`Loaded ${videoData.length} video lessons successfully.`);
    
    // Re-initialize any JavaScript that depends on the video cards
    initializeVideoCardFeatures();
}

// Function to initialize video card features after content is loaded
function initializeVideoCardFeatures() {
    // Re-run any existing JavaScript that operates on video cards
    const videoCards = document.querySelectorAll('.video-card');
    
    // Add data-category attributes to video cards
    videoCards.forEach((card, index) => {
        if (index < 3) {
            card.setAttribute('data-category', 'beginner');
        } else if (index < 7) {
            card.setAttribute('data-category', 'intermediate');
        } else {
            card.setAttribute('data-category', 'advanced');
        }
    });
    
    // Re-initialize Lucide icons if they exist
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
    
    // Apply translations to dynamically loaded content
    if (typeof window.applyTranslations === 'function') {
        window.applyTranslations();
    }
    
    console.log('Video card features initialized.');
}

// Export the load function for use by protection.js
window.loadSecureContent = loadVideoContent;

// Prevent direct access to video data
Object.freeze(videoData);

console.log('Content loader script initialized. Waiting for authentication verification...');