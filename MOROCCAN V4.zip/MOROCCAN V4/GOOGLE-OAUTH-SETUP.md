# Google OAuth Setup Guide

## Overview
This guide will help you configure Google OAuth authentication for your AI learning platform. You'll need to set up both Google Cloud Console and Firebase Console.

## Prerequisites
- Firebase project already created
- Google account with access to Google Cloud Console
- Your website domain (for production)

## Step 1: Google Cloud Console Setup

### 1.1 Create OAuth 2.0 Credentials
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Select your project (or create a new one)
3. Navigate to **APIs & Services** > **Credentials**
4. Click **+ CREATE CREDENTIALS** > **OAuth client ID**
5. If prompted, configure the OAuth consent screen first

### 1.2 Configure OAuth Consent Screen
1. Go to **APIs & Services** > **OAuth consent screen**
2. Choose **External** user type (unless you have Google Workspace)
3. Fill in the required information:
   - **App name**: الشارع المغربي AI Platform
   - **User support email**: Your email
   - **Developer contact information**: Your email
4. Add scopes (recommended):
   - `../auth/userinfo.email`
   - `../auth/userinfo.profile`
5. Add test users if in testing mode
6. Save and continue

### 1.3 Create OAuth Client ID
1. Return to **Credentials** > **+ CREATE CREDENTIALS** > **OAuth client ID**
2. Choose **Web application**
3. Configure:
   - **Name**: AI Platform Web Client
   - **Authorized JavaScript origins**:
     - `http://localhost:8000` (for development)
     - `http://127.0.0.1:8000` (for development)
     - `https://dawra.live` (for production)
   - **Authorized redirect URIs**:
     - `http://localhost:8000` (for development)
     - `https://dawra.live` (for production)
4. Click **Create**
5. **Important**: Copy the Client ID - you'll need it for Firebase

## Step 2: Firebase Console Setup

### 2.1 Enable Google Authentication
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your project
3. Navigate to **Authentication** > **Sign-in method**
4. Click on **Google** provider
5. Toggle **Enable**
6. Paste your **Web client ID** from Google Cloud Console
7. Paste your **Web client secret** from Google Cloud Console
8. Click **Save**

### 2.2 Configure Authorized Domains
1. In Firebase Console, go to **Authentication** > **Settings** > **Authorized domains**
2. Add your domains:
   - `localhost` (for development)
   - `dawra.live` (for production)

## Step 3: Update Your Code (Already Done)

The following features are already implemented in your codebase:

✅ **Google Authentication Provider** - Configured in `auth.js`
✅ **Sign-in with Google button** - Added to `login.html`
✅ **User data storage** - Saves Google user info to Firestore
✅ **Error handling** - Integrated with your error handler

## Step 4: Testing

### 4.1 Development Testing
1. Start your local server: `npx http-server . -p 8000`
2. Navigate to `http://localhost:8000/login.html`
3. Click "تسجيل الدخول بواسطة Google"
4. Complete the Google OAuth flow
5. Verify you're redirected to the dashboard

### 4.2 Production Deployment
1. Update authorized domains in both Google Cloud and Firebase
2. Test the OAuth flow on your production domain
3. Monitor the Firebase Authentication logs

## Step 5: Security Best Practices

### 5.1 Domain Restrictions
- Only add trusted domains to authorized origins
- Remove localhost/127.0.0.1 from production settings
- Use HTTPS in production

### 5.2 User Data Protection
- The system only stores necessary user information
- Profile photos are stored as URLs (not downloaded)
- Email and display name are the primary data points

## Troubleshooting

### Common Issues

**Error: "redirect_uri_mismatch"**
- Check that your domain is added to authorized redirect URIs
- Ensure the protocol (http/https) matches exactly

**Error: "invalid_client"**
- Verify the Client ID is correctly copied to Firebase
- Check that the OAuth client is enabled in Google Cloud

**Error: "access_denied"**
- User cancelled the OAuth flow
- Check OAuth consent screen configuration

**Error: "popup_blocked"**
- Browser blocked the popup window
- Advise users to allow popups for your domain

### Debug Steps
1. Check browser console for detailed error messages
2. Verify Firebase Authentication logs
3. Test with different browsers/incognito mode
4. Ensure all domains are properly configured

## Additional Features

Your authentication system now supports:

🔐 **Multiple Login Methods**:
- Email + Password
- Username + Password  
- Google OAuth

👤 **User Management**:
- Automatic user profile creation
- Username uniqueness validation
- Firestore integration for user data

🎨 **Enhanced UI**:
- Tab-based login method selection
- Loading states and error handling
- Responsive design

## Next Steps

1. **Test thoroughly** in development
2. **Configure production domains** when ready to deploy
3. **Consider adding more providers** (Facebook, Twitter, etc.)
4. **Implement user profile management** in the dashboard
5. **Add password reset functionality** for email users

---

**Need Help?**
If you encounter issues, check the browser console and Firebase Authentication logs for detailed error messages.