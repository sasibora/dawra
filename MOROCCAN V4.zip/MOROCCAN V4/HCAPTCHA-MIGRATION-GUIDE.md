# hCaptcha Migration Guide

## Overview

This project has been migrated from Google reCAPTCHA to hCaptcha for better privacy, security, and user experience.

## What Changed

### ✅ **Replaced Components:**
- ❌ Google reCAPTCHA Enterprise → ✅ hCaptcha
- ❌ `grecaptcha.enterprise.execute()` → ✅ `hCaptchaManager.executeHCaptcha()`
- ❌ reCAPTCHA script tags → ✅ Dynamic hCaptcha loading

### 📁 **Files Modified:**
- `js/env-config.js` - Added hCaptcha configuration
- `js/hcaptcha.js` - New hCaptcha manager (replaces reCAPTCHA functions)
- `js/login.js` - Updated to use hCaptcha
- `js/chat.js` - Updated to use hCaptcha
- `dashboard.html` - Removed reCAPTCHA script, added hCaptcha container
- `login.html` - Removed reCAPTCHA script, added hCaptcha container
- `pages/tools/login.html` - Added hCaptcha container

## Configuration Required

### 🔑 **Step 1: Update Sitekey**

In `js/env-config.js`, replace `YOUR_HCAPTCHA_SITEKEY` with your actual hCaptcha sitekey:

```javascript
HCAPTCHA: {
    siteKey: 'YOUR_ACTUAL_SITEKEY_HERE', // Replace this!
    secretKey: 'ES_f4544ff574e24db88e4327e181784409' // Already configured
}
```

### 🌐 **Step 2: Get Your Sitekey**

If you don't have your complete sitekey:

1. Go to [hCaptcha Dashboard](https://dashboard.hcaptcha.com/)
2. Navigate to **Sites** section
3. Copy your **Sitekey**
4. Update the configuration file

## How hCaptcha Works

### 🔒 **Invisible Protection**
- hCaptcha runs invisibly in the background
- Only shows challenges when suspicious activity is detected
- Better user experience than traditional CAPTCHAs

### 🎯 **Actions Protected:**
- `LOGIN` - User authentication
- `SEND_MESSAGE` - Chat/messaging functionality
- `LOGOUT` - User logout

### 📱 **Implementation Details:**

```javascript
// Example usage
const { hCaptchaManager } = await import('./hcaptcha.js');
const token = await hCaptchaManager.executeHCaptcha('LOGIN');
```

## Benefits of hCaptcha

### 🛡️ **Security:**
- Advanced bot detection
- Machine learning-based threat analysis
- Real-time risk assessment

### 🔐 **Privacy:**
- GDPR compliant
- No personal data collection
- Transparent privacy practices

### ⚡ **Performance:**
- Faster loading times
- Smaller script size
- Better mobile experience

### 💰 **Cost-Effective:**
- Free tier available
- Pay-per-use pricing
- No hidden fees

## Fallback Behavior

If hCaptcha fails to load or execute:
- System continues with `fallback-token`
- User experience is not interrupted
- Security warnings are logged for monitoring

## Testing

### ✅ **Verify Integration:**

1. **Check Console Logs:**
   ```
   ✅ "hCaptcha loaded successfully"
   ✅ "hCaptcha token generated for action: LOGIN"
   ```

2. **Test Actions:**
   - Login process
   - Send messages in chat
   - Logout functionality

3. **Fallback Testing:**
   - Block hCaptcha script in browser
   - Verify fallback behavior works

## Troubleshooting

### ❌ **"hCaptcha not loaded"**
**Solution:** Check network connectivity and sitekey configuration

### ❌ **"Invalid sitekey"**
**Solution:** Verify sitekey in `env-config.js` matches your hCaptcha dashboard

### ❌ **"Domain not allowed"**
**Solution:** Add your domain to allowed domains in hCaptcha dashboard

## Migration Checklist

- [x] Remove Google reCAPTCHA scripts
- [x] Install hCaptcha manager
- [x] Update authentication flows
- [x] Update chat functionality
- [x] Update logout process
- [x] Add hCaptcha containers to HTML
- [ ] **Configure actual sitekey** ⚠️ **REQUIRED**
- [ ] Test all protected actions
- [ ] Verify fallback behavior

## Next Steps

1. **Update the sitekey** in `js/env-config.js`
2. Test the login, chat, and logout functionality
3. Monitor console logs for any issues
4. Configure hCaptcha dashboard settings as needed

---

**Note:** The secret key `ES_f4544ff574e24db88e4327e181784409` is already configured and should be used for server-side verification.