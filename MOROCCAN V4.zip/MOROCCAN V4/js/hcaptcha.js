// hCaptcha Integration Module
// Replaces Google reCAPTCHA with hCaptcha for better privacy and security

class HCaptchaManager {
    constructor() {
        this.siteKey = null;
        this.isLoaded = false;
        this.loadPromise = null;
        this.configLoaded = false;
    }

    // Load configuration dynamically
    async loadConfig() {
        if (this.configLoaded) return;
        
        try {
            let configModule;
            if (window.location.pathname.includes('/pages/')) {
                configModule = await import('../../js/env-config.js');
            } else {
                configModule = await import('./env-config.js');
            }
            this.siteKey = configModule.ENV_CONFIG.HCAPTCHA.siteKey;
            this.configLoaded = true;
        } catch (error) {
            console.error('Failed to load hCaptcha configuration:', error);
            throw error;
        }
    }

    // Load hCaptcha script dynamically
    async loadHCaptcha() {
        if (this.loadPromise) {
            return this.loadPromise;
        }

        this.loadPromise = new Promise((resolve, reject) => {
            // Check if hCaptcha is already loaded
            if (window.hcaptcha) {
                this.isLoaded = true;
                resolve(window.hcaptcha);
                return;
            }

            // Create script element
            const script = document.createElement('script');
            script.src = 'https://js.hcaptcha.com/1/api.js';
            script.async = true;
            script.defer = true;

            script.onload = () => {
                this.isLoaded = true;
                console.log('hCaptcha loaded successfully');
                resolve(window.hcaptcha);
            };

            script.onerror = (error) => {
                console.error('Failed to load hCaptcha:', error);
                reject(new Error('hCaptcha failed to load'));
            };

            document.head.appendChild(script);
        });

        return this.loadPromise;
    }

    // Execute hCaptcha verification
    async executeHCaptcha(action = 'submit') {
        try {
            // Load configuration first
            await this.loadConfig();
            
            // Check if we're on localhost - hCaptcha doesn't work on localhost
            if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
                console.warn('Development mode detected (localhost) - bypassing hCaptcha verification');
                return 'fallback-token';
            }

            // Ensure hCaptcha is loaded
            await this.loadHCaptcha();

            if (!window.hcaptcha) {
                console.warn('hCaptcha not available - continuing without protection');
                return 'fallback-token';
            }

            // For invisible hCaptcha, we need to render and execute
            return new Promise((resolve, reject) => {
                const widgetId = window.hcaptcha.render('hcaptcha-container', {
                    sitekey: this.siteKey,
                    size: 'invisible',
                    callback: (token) => {
                        console.log('hCaptcha token generated for action:', action);
                        resolve(token);
                    },
                    'error-callback': (error) => {
                        console.warn('hCaptcha execution failed:', error);
                        resolve('fallback-token');
                    }
                });

                // Execute the captcha
                window.hcaptcha.execute(widgetId);
            });

        } catch (error) {
            console.warn('hCaptcha execution failed - continuing without protection:', error);
            return 'fallback-token';
        }
    }

    // Render visible hCaptcha widget
    renderWidget(containerId, callback) {
        return new Promise(async (resolve, reject) => {
            try {
                // Load configuration first
                await this.loadConfig();
                await this.loadHCaptcha();
                
                const widgetId = window.hcaptcha.render(containerId, {
                    sitekey: this.siteKey,
                    callback: callback || function(token) {
                        console.log('hCaptcha completed:', token);
                    },
                    'error-callback': function(error) {
                        console.error('hCaptcha error:', error);
                    }
                });
                
                resolve(widgetId);
            } catch (error) {
                reject(error);
            }
        });
    }

    // Reset hCaptcha widget
    reset(widgetId) {
        if (window.hcaptcha && widgetId !== undefined) {
            window.hcaptcha.reset(widgetId);
        }
    }

    // Get response token
    getResponse(widgetId) {
        if (window.hcaptcha && widgetId !== undefined) {
            return window.hcaptcha.getResponse(widgetId);
        }
        return null;
    }

    // Check if hCaptcha is ready
    isReady() {
        return this.isLoaded && window.hcaptcha;
    }
}

// Create singleton instance
const hCaptchaManager = new HCaptchaManager();

// Export for ES6 modules
export { hCaptchaManager };

// Also make it available globally for backward compatibility
if (typeof window !== 'undefined') {
    window.hCaptchaManager = hCaptchaManager;
}

// Default export
export default hCaptchaManager;