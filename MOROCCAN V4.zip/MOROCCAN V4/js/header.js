// Header Component
class HeaderComponent {
    constructor() {
        console.log('HeaderComponent constructor called');
        this.init();
    }

    async init() {
        console.log('HeaderComponent init called');
        this.createHeader();
        this.setupEventListeners();
        await this.checkAuthState();
    }

    async checkAuthState() {
        try {
            // Wait for auth manager to be available
            if (typeof window.authManager !== 'undefined') {
                await window.authManager.init();
                const isAuthenticated = await window.authManager.isAuthenticated();
                
                if (isAuthenticated) {
                    const user = await window.authManager.getCurrentUser();
                    this.updateUIForLoggedInUser(user);
                }
                
                // Listen for auth state changes
                window.authManager.onAuthStateChange((event, session) => {
                    if (event === 'SIGNED_IN' && session) {
                        this.updateUIForLoggedInUser(session.user);
                    } else if (event === 'SIGNED_OUT') {
                        this.updateUIForLoggedOutUser();
                    }
                });
            }
        } catch (error) {
            console.error('Error checking auth state:', error);
        }
    }

    updateUIForLoggedInUser(user) {
        const loginBtn = document.getElementById('login-btn');
        const mobileLoginBtn = document.getElementById('mobile-login-btn');
        
        if (loginBtn) {
            loginBtn.innerHTML = `
                <i data-lucide="user-check" class="w-4 h-4"></i>
                <span>${user.email || 'مستخدم'}</span>
            `;
            loginBtn.onclick = () => window.location.href = 'dashboard.html';
        }
        
        if (mobileLoginBtn) {
            mobileLoginBtn.innerHTML = `
                <i data-lucide="user-check" class="w-4 h-4"></i>
                <span>لوحة التحكم</span>
            `;
            mobileLoginBtn.onclick = () => window.location.href = 'dashboard.html';
        }
        
        // Refresh Lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    updateUIForLoggedOutUser() {
        const loginBtn = document.getElementById('login-btn');
        const mobileLoginBtn = document.getElementById('mobile-login-btn');
        
        if (loginBtn) {
            loginBtn.innerHTML = `
                <i data-lucide="user" class="w-4 h-4"></i>
                <span>تسجيل الدخول</span>
            `;
            loginBtn.onclick = () => window.location.href = 'login.html';
        }
        
        if (mobileLoginBtn) {
            mobileLoginBtn.innerHTML = `
                <i data-lucide="user" class="w-4 h-4"></i>
                <span>تسجيل الدخول</span>
            `;
            mobileLoginBtn.onclick = () => window.location.href = 'login.html';
        }
        
        // Refresh Lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    createHeader() {
        console.log('createHeader called');
        // Determine if we're on index.html or another page
        const isIndexPage = window.location.pathname === '/' || window.location.pathname.endsWith('/index.html') || window.location.pathname.endsWith('/newsite/') || window.location.pathname === '/newsite/index.html';
        const baseUrl = isIndexPage ? '' : this.getBaseUrl();
        
        // Calculate asset path separately
        const currentPath = window.location.pathname;
        const pathParts = currentPath.split('/').filter(part => part !== '');
        const fileName = pathParts[pathParts.length - 1];
        if (fileName && fileName.includes('.html')) {
            pathParts.pop();
        }
        const depth = pathParts.length;
        let assetPath = '../'.repeat(depth);
        
        // Special handling for pages in tools directory
        if (currentPath.includes('/pages/tools/')) {
            assetPath = '../../';
        }
        
        console.log('isIndexPage:', isIndexPage, 'baseUrl:', baseUrl, 'assetPath:', assetPath);
         console.log('Final logo path will be:', assetPath + 'assets/images/logo.svg');
        
        const headerHTML = `
            <!-- Navigation -->
            <header>
                <nav class="container mx-auto px-6 py-4 flex justify-between items-center">
                    <!-- Logo -->
                    <div class="flex-shrink-0">
                        <a href="https://dawra.live" target="_blank" rel="noopener noreferrer" class="flex items-center gap-3">
                            <img src="${assetPath}assets/images/logo.svg" alt="شعار الشارع المغربي" class="w-12 h-12 rounded-full border-2 border-brand-gold" loading="lazy" onerror="this.onerror=null;this.src='https://placehold.co/48x48/8B1538/ffffff?text=AI';">
                            <h1 class="text-xl font-bold text-white hidden sm:block">الشارع المغربي</h1>
                        </a>
                    </div>
                    
                    <!-- Desktop Menu & Right-side controls -->
                    <div class="hidden md:flex items-center gap-6">
                        <a href="${baseUrl}#hero" class="nav-link text-slate-300">الرئيسية</a>
                        <a href="${baseUrl}#features" class="nav-link text-slate-300">الدورة</a>
                        <a href="${baseUrl}#curriculum" class="nav-link text-slate-300">المنهج</a>
                        <a href="${baseUrl}#instructor" class="nav-link text-slate-300">المدرب</a>
                        <a href="${baseUrl}#pricing" class="nav-link text-slate-300">الأسعار</a>
                        <a href="${baseUrl}#knowledge-base" class="nav-link text-slate-300">المعرفة</a>
                    </div>
                    <div class="hidden md:flex items-center gap-3">
                        <button id="login-btn" class="btn-interactive glass-card text-slate-300 hover:text-brand-gold font-semibold py-2 px-4 rounded-lg transition flex items-center gap-2">
                            <i data-lucide="user" class="w-4 h-4"></i>
                            <span>تسجيل الدخول</span>
                        </button>
                        <button id="auth-btn" class="btn-primary btn-interactive text-white font-bold py-3 px-6 rounded-lg">ابدأ الآن</button>
                    </div>

                    <!-- Mobile Menu Button -->
                    <div class="md:hidden flex items-center">
                        <button id="mobile-login-btn" class="text-slate-300 hover:text-brand-gold mr-2">
                            <i data-lucide="user" class="w-6 h-6"></i>
                        </button>
                        <button id="mobile-menu-button" class="text-white focus:outline-none">
                            <i data-lucide="menu" class="w-8 h-8"></i>
                        </button>
                    </div>
                </nav>

                <!-- Mobile Menu -->
                <div id="mobile-menu" class="hidden md:hidden glass-card-strong">
                    <div class="px-2 pt-2 pb-4 space-y-2 flex flex-col items-center">
                        <a href="${baseUrl}#hero" class="nav-link text-slate-300 block px-3 py-2 rounded-md text-base font-medium">الرئيسية</a>
                        <a href="${baseUrl}#features" class="nav-link text-slate-300 block px-3 py-2 rounded-md text-base font-medium">الدورة</a>
                        <a href="${baseUrl}#curriculum" class="nav-link text-slate-300 block px-3 py-2 rounded-md text-base font-medium">المنهج</a>
                        <a href="${baseUrl}#instructor" class="nav-link text-slate-300 block px-3 py-2 rounded-md text-base font-medium">المدرب</a>
                        <a href="${baseUrl}#pricing" class="nav-link text-slate-300 block px-3 py-2 rounded-md text-base font-medium">الأسعار</a>
                        <a href="${baseUrl}#knowledge-base" class="nav-link text-slate-300 block px-3 py-2 rounded-md text-base font-medium">المعرفة</a>
                        <button id="mobile-auth-btn" class="btn-primary btn-interactive text-white font-bold py-3 px-8 rounded-lg mt-4">ابدأ الآن</button>
                    </div>
                </div>
            </header>
        `;

        // Add header to the beginning of body
        console.log('Inserting header HTML');
        document.body.insertAdjacentHTML('afterbegin', headerHTML);
        console.log('Header inserted, checking if it exists:', document.querySelector('header'));
        
        // Force CSS reflow and ensure sticky positioning
        const newHeader = document.querySelector('header');
        if (newHeader) {
            // Force a reflow to ensure CSS is applied
            newHeader.offsetHeight;
            // Ensure sticky positioning is applied
            newHeader.style.position = 'sticky';
            newHeader.style.top = '0';
            newHeader.style.zIndex = '9999';
        }
        
        // Initialize scroll-based header background with a small delay
        setTimeout(() => {
            this.initializeScrollHeader();
        }, 100);
    }

    getBaseUrl() {
        // Get the current path and determine the base URL for index.html
        const currentPath = window.location.pathname;
        
        // Count the directory depth to determine how many '../' we need
        const pathParts = currentPath.split('/').filter(part => part !== '');
        const fileName = pathParts[pathParts.length - 1];
        
        // Remove the filename from the path parts to get directory depth
        if (fileName && fileName.includes('.html')) {
            pathParts.pop();
        }
        
        // Calculate relative path back to root
        const depth = pathParts.length;
        const relativePath = '../'.repeat(depth);
        
        return relativePath + 'index.html';
    }

    setupEventListeners() {
        // Wait a bit for the DOM to be updated
        setTimeout(() => {
            // Mobile menu toggle
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            
            if (mobileMenuButton && mobileMenu) {
                mobileMenuButton.addEventListener('click', () => {
                    mobileMenu.classList.toggle('hidden');
                });
            }

            // Setup active navigation tracking
            this.setupActiveNavigation();

            // Login button handlers
            const loginBtn = document.getElementById('login-btn');
            const mobileLoginBtn = document.getElementById('mobile-login-btn');
            const authBtn = document.getElementById('auth-btn');
            const mobileAuthBtn = document.getElementById('mobile-auth-btn');

            if (loginBtn) {
                loginBtn.addEventListener('click', () => {
                    window.location.href = 'login.html';
                });
            }

            if (mobileLoginBtn) {
                mobileLoginBtn.addEventListener('click', () => {
                    window.location.href = 'login.html';
                });
            }

            // Auth buttons functionality removed - modal completely removed
        }, 100);
    }

    setupActiveNavigation() {
        // Get all navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        
        // Function to update active states
        const updateActiveStates = () => {
            const currentHash = window.location.hash || '#hero';
            
            navLinks.forEach(link => {
                const href = link.getAttribute('href');
                if (href && href.includes(currentHash)) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            });
        };

        // Update on hash change
        window.addEventListener('hashchange', updateActiveStates);
        
        // Update on page load
        updateActiveStates();

        // Optional: Update based on scroll position (for single page applications)
        if (window.location.pathname === '/' || window.location.pathname.endsWith('/index.html')) {
            const sections = ['hero', 'features', 'curriculum', 'instructor', 'pricing', 'knowledge-base'];
            
            const observerOptions = {
                root: null,
                rootMargin: '-50% 0px -50% 0px',
                threshold: 0
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const sectionId = entry.target.id;
                        navLinks.forEach(link => {
                            const href = link.getAttribute('href');
                            if (href && href.includes(`#${sectionId}`)) {
                                link.classList.add('active');
                            } else {
                                link.classList.remove('active');
                            }
                        });
                    }
                });
            }, observerOptions);

            // Observe all sections
            sections.forEach(sectionId => {
                const section = document.getElementById(sectionId);
                if (section) {
                    observer.observe(section);
                }
            });
        }
    }

    initializeScrollHeader() {
        const header = document.querySelector('header');
        
        if (!header) return;
        
        let ticking = false;
        
        const handleScroll = () => {
            if (!ticking) {
                requestAnimationFrame(() => {
                    const scrollY = window.scrollY;
                    
                    // Add scrolled class for enhanced styling when scrolled
                    if (scrollY > 50) {
                        header.classList.add('scrolled');
                    } else {
                        header.classList.remove('scrolled');
                    }
                    
                    ticking = false;
                });
                ticking = true;
            }
        };
        
        // Use passive listener for better performance
        window.addEventListener('scroll', handleScroll, { passive: true });
        
        // Call once to set initial state
        handleScroll();
    }


}

// Initialize header component when DOM is loaded
console.log('Header.js script loaded');
// alert('Header.js loaded - check if you see this alert');
if (document.readyState === 'loading') {
    console.log('DOM is loading, adding event listener');
    document.addEventListener('DOMContentLoaded', () => {
        console.log('DOMContentLoaded fired, creating HeaderComponent');
        // alert('Creating HeaderComponent');
        new HeaderComponent();
    });
} else {
    console.log('DOM already loaded, creating HeaderComponent immediately');
    alert('Creating HeaderComponent immediately');
    new HeaderComponent();
}