// AuthManager - Unified authentication interface
class AuthManager {
    constructor() {
        this.supabaseClient = null;
        this.initialized = false;
    }

    // Initialize the auth manager
    async init() {
        if (this.initialized) return;
        
        try {
            // Wait for global Supabase client to be available
            await this.waitForSupabase();
            this.supabaseClient = window.supabaseClient;
            this.initialized = true;
            console.log('AuthManager initialized successfully');
        } catch (error) {
            console.error('Failed to initialize AuthManager:', error);
            throw error;
        }
    }

    // Wait for Supabase client to be available
    async waitForSupabase(maxAttempts = 50) {
        for (let i = 0; i < maxAttempts; i++) {
            if (window.supabaseClient) {
                return window.supabaseClient;
            }
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        throw new Error('Supabase client not available');
    }

    // Get the Supabase client instance
    getSupabaseClient() {
        if (!this.supabaseClient) {
            throw new Error('AuthManager not initialized. Call init() first.');
        }
        return this.supabaseClient;
    }

    // Get current user
    async getCurrentUser() {
        try {
            if (!this.supabaseClient) await this.init();
            const { data: { user }, error } = await this.supabaseClient.auth.getUser();
            if (error) throw error;
            return user;
        } catch (error) {
            console.error('Error getting current user:', error);
            return null;
        }
    }

    // Get current session
    async getSession() {
        try {
            if (!this.supabaseClient) await this.init();
            const { data: { session }, error } = await this.supabaseClient.auth.getSession();
            if (error) throw error;
            return session;
        } catch (error) {
            console.error('Error getting session:', error);
            return null;
        }
    }

    // Check if user is authenticated
    async isAuthenticated() {
        try {
            const user = await this.getCurrentUser();
            return !!user;
        } catch (error) {
            console.error('Error checking authentication:', error);
            return false;
        }
    }

    // Sign out user
    async signOut() {
        try {
            if (!this.supabaseClient) await this.init();
            const { error } = await this.supabaseClient.auth.signOut();
            if (error) throw error;
            
            // Clear any cached data
            localStorage.removeItem('supabase.auth.token');
            sessionStorage.clear();
            
            return true;
        } catch (error) {
            console.error('Error signing out:', error);
            return false;
        }
    }

    // Listen to auth state changes
    onAuthStateChange(callback) {
        if (!this.supabaseClient) {
            console.warn('AuthManager not initialized for auth state change listener');
            return () => {};
        }
        
        const { data: { subscription } } = this.supabaseClient.auth.onAuthStateChange(
            (event, session) => {
                console.log('Auth state changed:', event, session?.user?.email);
                callback(event, session);
            }
        );
        
        return () => subscription.unsubscribe();
    }

    // Initialize session (for compatibility)
    async initializeSession() {
        try {
            const session = await this.getSession();
            return session;
        } catch (error) {
            console.error('Error initializing session:', error);
            return null;
        }
    }

    // Send OTP to email
    async sendOTP(email) {
        try {
            if (!this.supabaseClient) await this.init();
            
            const { data, error } = await this.supabaseClient.auth.signInWithOtp({
                email: email,
                options: {
                    shouldCreateUser: true,
                    emailRedirectTo: window.location.origin + '/dashboard.html',
                    // Skip captcha for localhost development
                    captchaToken: null
                }
            });
            
            if (error) throw error;
            return { success: true, data };
        } catch (error) {
            console.error('Error sending OTP:', error);
            return { success: false, error: error.message };
        }
    }

    // Verify OTP
    async verifyOTP(email, token) {
        try {
            if (!this.supabaseClient) await this.init();
            
            const { data, error } = await this.supabaseClient.auth.verifyOtp({
                email: email,
                token: token,
                type: 'email'
            });
            
            if (error) throw error;
            return { success: true, data };
        } catch (error) {
            console.error('Error verifying OTP:', error);
            return { success: false, error: error.message };
        }
    }
}

// Create and export a single instance
const authManager = new AuthManager();

// Export for ES6 modules
export { authManager };

// Also make it available globally for backward compatibility
if (typeof window !== 'undefined') {
    window.authManager = authManager;
}

// Default export
export default authManager;