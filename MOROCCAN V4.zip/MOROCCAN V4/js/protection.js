// Page Protection - Simple authentication check
import { authManager } from './auth.js';

class PageProtection {
    constructor(options = {}) {
        this.redirectUrl = options.redirectUrl || '/login.html';
        this.allowedPaths = options.allowedPaths || [];
        this.authManager = authManager;
        this.init();
    }

    async init() {
        try {
            // Check if user came from dashboard (protected access)
            const dashboardAccess = sessionStorage.getItem('dashboardAccess');
            const referrer = document.referrer;
            const isDashboardAccess = dashboardAccess === 'true' || referrer.includes('dashboard.html');
            
            // Initialize auth manager
            await this.authManager.init();
            
            if (isDashboardAccess) {
                // Protected mode: require authentication
                const isAuthenticated = await this.authManager.isAuthenticated();
                
                if (!isAuthenticated) {
                    this.redirectToLogin();
                    return;
                }
                
                // Listen for auth state changes
                this.authManager.onAuthStateChange((event, session) => {
                    if (event === 'SIGNED_OUT' || !session) {
                        this.redirectToLogin();
                    }
                });
                
                console.log('Page protection initialized - user is authenticated (dashboard access)');
            } else {
                // Public mode: no authentication required, but still initialize auth for features
                console.log('Page accessed publicly - no authentication required');
                
                // Still listen for auth state for potential features
                this.authManager.onAuthStateChange((event, session) => {
                    // Optional: handle auth state changes for public access
                });
            }
            
        } catch (error) {
            console.error('Error initializing page protection:', error);
            // Only redirect to login if this was dashboard access
            const dashboardAccess = sessionStorage.getItem('dashboardAccess');
            const referrer = document.referrer;
            const isDashboardAccess = dashboardAccess === 'true' || referrer.includes('dashboard.html');
            
            if (isDashboardAccess) {
                this.redirectToLogin();
            }
        }
    }



    redirectToLogin() {
        const currentPath = window.location.pathname;
        const currentUrl = window.location.href;
        
        // Don't redirect if already on login page or allowed paths
        if (currentPath.includes('login.html') || this.allowedPaths.some(path => currentPath.includes(path))) {
            return;
        }
        
        console.log('User not authenticated, redirecting to login');
        
        // Redirect to login with return URL
        const loginUrl = new URL(this.redirectUrl, window.location.origin);
        loginUrl.searchParams.set('redirect', currentUrl);
        
        window.location.href = loginUrl.toString();
    }

    // Static method to quickly protect a page
    static protect(options = {}) {
        return new PageProtection(options);
    }
}

// Auto-protect functionality removed to prevent conflicts with manual authentication checks

// Export for ES6 modules
export default PageProtection;

// Make it available globally
if (typeof window !== 'undefined') {
    window.PageProtection = PageProtection;
}