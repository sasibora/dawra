export const PATHS = {
    CSS: {
        GLOBAL: 'css/global.css',
        FORMS: 'css/forms.css'
    },
    ASSETS: {
        IMAGES: 'assets/images/',
        LOGOS: 'assets/logos/'
    }
};