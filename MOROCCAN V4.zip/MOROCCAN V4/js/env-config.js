// Environment Configuration
// This file should be excluded from version control (.gitignore)
// Copy this file and rename to env-config.js, then fill in your actual values

export const ENV_CONFIG = {
    // AI API Configuration
    AI_API: {
        // For Together AI (Recommended)
        // Replace with your actual API key when ready
        apiKey: 'DEMO_MODE', // Set to 'DEMO_MODE' for testing without API
        apiUrl: 'https://api.together.xyz/v1/chat/completions',
        model: 'meta-llama/Llama-3-8b-chat-hf',
        
        // Chat settings
        maxTokens: 500,
        temperature: 0.7
    }
};

// Browser environment - using direct configuration values
console.log('Using browser configuration');