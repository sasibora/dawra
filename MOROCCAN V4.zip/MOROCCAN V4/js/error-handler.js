// Centralized Error Handling Utility
class ErrorHandler {
    static showError(message, type = 'error') {
        // Remove any existing error messages
        this.clearErrors();
        
        const errorDiv = document.createElement('div');
        errorDiv.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-md transition-all duration-300 transform translate-x-full`;
        errorDiv.id = 'error-notification';
        
        // Set styles based on error type
        switch(type) {
            case 'success':
                errorDiv.className += ' bg-green-500 text-white';
                break;
            case 'warning':
                errorDiv.className += ' bg-yellow-500 text-white';
                break;
            case 'info':
                errorDiv.className += ' bg-blue-500 text-white';
                break;
            default:
                errorDiv.className += ' bg-red-500 text-white';
        }
        
        errorDiv.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="ml-3">
                        <p class="text-sm font-medium">${message}</p>
                    </div>
                </div>
                <button onclick="ErrorHandler.clearErrors()" class="text-white hover:text-gray-200">
                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                    </svg>
                </button>
            </div>
        `;
        
        document.body.appendChild(errorDiv);
        
        // Animate in
        setTimeout(() => {
            errorDiv.classList.remove('translate-x-full');
        }, 100);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            this.clearErrors();
        }, 5000);
    }
    
    static clearErrors() {
        const existingError = document.getElementById('error-notification');
        if (existingError) {
            existingError.classList.add('translate-x-full');
            setTimeout(() => {
                existingError.remove();
            }, 300);
        }
    }
    
    static handleApiError(error) {
        console.error('API Error:', error);
        
        if (error.message.includes('API key')) {
            this.showError('خطأ في مفتاح API. يرجى التحقق من الإعدادات.');
        } else if (error.message.includes('network') || error.message.includes('fetch')) {
            this.showError('خطأ في الاتصال. يرجى التحقق من اتصال الإنترنت.');
        } else if (error.message.includes('401')) {
            this.showError('غير مصرح. يرجى تسجيل الدخول مرة أخرى.');
        } else if (error.message.includes('429')) {
            this.showError('تم تجاوز الحد المسموح. يرجى المحاولة لاحقاً.');
        } else {
            this.showError('حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.');
        }
    }
    
    static handleAuthError(error) {
        console.error('Auth Error:', error);
        
        if (error.code === 'auth/user-not-found') {
            this.showError('المستخدم غير موجود.');
        } else if (error.code === 'auth/wrong-password') {
            this.showError('كلمة المرور غير صحيحة.');
        } else if (error.code === 'auth/email-already-in-use') {
            this.showError('البريد الإلكتروني مستخدم بالفعل.');
        } else if (error.code === 'auth/weak-password') {
            this.showError('كلمة المرور ضعيفة. يجب أن تكون 6 أحرف على الأقل.');
        } else if (error.code === 'auth/invalid-email') {
            this.showError('البريد الإلكتروني غير صحيح.');
        } else {
            this.showError('خطأ في المصادقة. يرجى المحاولة مرة أخرى.');
        }
    }
    
    static showSuccess(message) {
        this.showError(message, 'success');
    }
    
    static showWarning(message) {
        this.showError(message, 'warning');
    }
    
    static showInfo(message) {
        this.showError(message, 'info');
    }
}

// Make it globally available
window.ErrorHandler = ErrorHandler;