// Shared Components JavaScript
// Provides common functionality for components across the application

class SharedComponents {
    constructor() {
        this.init();
    }

    init() {
        this.initCategoryPills();
        this.initCopyButtons();
        this.initSearchFunctionality();
        this.initStatsCards();
    }

    // Initialize category filter pills
    initCategoryPills() {
        const categoryPills = document.querySelectorAll('.category-pill');
        const promptCards = document.querySelectorAll('#prompts-content .glass-card');

        categoryPills.forEach(pill => {
            pill.addEventListener('click', () => {
                // Remove active class from all pills
                categoryPills.forEach(p => p.classList.remove('active'));
                // Add active class to clicked pill
                pill.classList.add('active');

                const category = pill.dataset.category;
                
                // Filter prompt cards
                promptCards.forEach(card => {
                    const cardCategory = card.querySelector('.text-xs').textContent;
                    if (category === 'all' || cardCategory.includes(this.getCategoryText(category))) {
                        card.style.display = 'block';
                        card.classList.add('fade-in');
                    } else {
                        card.style.display = 'none';
                        card.classList.remove('fade-in');
                    }
                });
            });
        });
    }

    // Get category text based on category key
    getCategoryText(category) {
        const categoryMap = {
            'text': 'توليد النصوص',
            'image': 'توليد الصور',
            'video': 'توليد الفيديو',
            'strategy': 'استراتيجية',
            'optimization': 'تحسين'
        };
        return categoryMap[category] || category;
    }

    // Initialize copy buttons for prompts
    initCopyButtons() {
        const copyButtons = document.querySelectorAll('.btn-primary');
        
        copyButtons.forEach(button => {
            if (button.textContent.includes('نسخ')) {
                button.addEventListener('click', () => {
                    const promptCard = button.closest('.glass-card');
                    const promptText = promptCard.querySelector('p').textContent;
                    
                    // Copy to clipboard
                    navigator.clipboard.writeText(promptText).then(() => {
                        // Show success feedback
                        const originalText = button.textContent;
                        button.textContent = 'تم النسخ!';
                        button.classList.add('bg-green-600');
                        
                        setTimeout(() => {
                            button.textContent = originalText;
                            button.classList.remove('bg-green-600');
                        }, 2000);
                    }).catch(err => {
                        console.error('Failed to copy text: ', err);
                        // Fallback for older browsers
                        this.fallbackCopyTextToClipboard(promptText, button);
                    });
                });
            }
        });
    }

    // Fallback copy method for older browsers
    fallbackCopyTextToClipboard(text, button) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            const originalText = button.textContent;
            button.textContent = 'تم النسخ!';
            button.classList.add('bg-green-600');
            
            setTimeout(() => {
                button.textContent = originalText;
                button.classList.remove('bg-green-600');
            }, 2000);
        } catch (err) {
            console.error('Fallback copy failed: ', err);
        }
        
        document.body.removeChild(textArea);
    }

    // Initialize search functionality
    initSearchFunctionality() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase();
                const promptCards = document.querySelectorAll('#prompts-content .glass-card');
                
                promptCards.forEach(card => {
                    const title = card.querySelector('h3').textContent.toLowerCase();
                    const description = card.querySelector('p').textContent.toLowerCase();
                    const category = card.querySelector('.text-xs').textContent.toLowerCase();
                    
                    if (title.includes(searchTerm) || 
                        description.includes(searchTerm) || 
                        category.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        }
    }

    // Initialize stats cards with animations
    initStatsCards() {
        const statsCards = document.querySelectorAll('.stats-card');
        
        const statsObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-pulse');
                    setTimeout(() => {
                        entry.target.classList.remove('animate-pulse');
                    }, 1000);
                }
            });
        }, { threshold: 0.5 });

        statsCards.forEach(card => {
            statsObserver.observe(card);
        });
    }

    // Utility method to show notifications
    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg text-white ${
            type === 'success' ? 'bg-green-600' : 'bg-red-600'
        }`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SharedComponents;
} 