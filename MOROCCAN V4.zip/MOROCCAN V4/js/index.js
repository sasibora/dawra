// Index page specific JavaScript

document.addEventListener('DOMContentLoaded', function () {

    // Countdown Timer
    const countdownDate = new Date("September 1, 2025 00:00:00").getTime();
    const countdownElement = document.getElementById('countdown');
    if (countdownElement) {
        const interval = setInterval(() => {
            const now = new Date().getTime();
            const distance = countdownDate - now;
            if (distance < 0) {
                clearInterval(interval);
                countdownElement.innerHTML = `<p class='text-xl font-bold text-brand-gold'>انتهى العرض!</p>`;
                return;
            }
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            document.getElementById('days').innerText = days.toString().padStart(2, '0');
            document.getElementById('hours').innerText = hours.toString().padStart(2, '0');
            document.getElementById('minutes').innerText = minutes.toString().padStart(2, '0');
            document.getElementById('seconds').innerText = seconds.toString().padStart(2, '0');
        }, 1000);
    }

    // FAQ Accordion
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            const content = item.querySelector('.faq-content');
            const icon = item.querySelector('.faq-icon');
            content.classList.toggle('open');
            icon.classList.toggle('rotate-45');
        });
    });




});