// Chat Manager - AI Chat Interface
// Uses globally available authManager and API_CONFIG

class ChatManager {
    constructor() {
        this.chatContainer = null;
        this.messageInput = null;
        this.sendButton = null;
        this.authManager = null;
        this.apiKey = null;
        this.apiUrl = null;
        this.model = null;
        this.maxTokens = null;
        this.temperature = null;
        this.systemPrompt = null;
        this.initialized = false;
    }

    async init() {
        if (this.initialized) return;
        
        try {
            // Wait for global authManager to be available
            await this.waitForAuthManager();
            this.authManager = window.authManager;
            
            // Wait for global API_CONFIG to be available
            await this.waitForAPIConfig();
            
            // Initialize API configuration
            this.apiKey = window.API_CONFIG.apiKey;
            this.apiUrl = window.API_CONFIG.apiUrl;
            this.model = window.API_CONFIG.model;
            this.maxTokens = window.API_CONFIG.maxTokens;
            this.temperature = window.API_CONFIG.temperature;
            this.systemPrompt = window.API_CONFIG.systemPrompt;
            
            this.chatContainer = document.getElementById('chat-messages');
            this.messageInput = document.getElementById('message-input');
            this.sendButton = document.getElementById('send-button');
            
            if (this.sendButton) {
                this.sendButton.addEventListener('click', () => this.sendMessage());
            }
            
            if (this.messageInput) {
                this.messageInput.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.sendMessage();
                    }
                });
            }

            this.initialized = true;
            this.loadChatHistory();
        } catch (error) {
            console.error('Failed to initialize ChatManager:', error);
            throw error;
        }
    }

    // Wait for auth manager to be available
    async waitForAuthManager() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 50;
            
            const checkAuthManager = () => {
                if (typeof window !== 'undefined' && window.authManager) {
                    resolve();
                } else if (attempts >= maxAttempts) {
                    reject(new Error('AuthManager not available after maximum attempts'));
                } else {
                    attempts++;
                    setTimeout(checkAuthManager, 100);
                }
            };
            
            checkAuthManager();
        });
    }

    // Wait for API config to be available
    async waitForAPIConfig() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 50;
            
            const checkAPIConfig = () => {
                if (typeof window !== 'undefined' && window.API_CONFIG) {
                    resolve();
                } else if (attempts >= maxAttempts) {
                    reject(new Error('API_CONFIG not available after maximum attempts'));
                } else {
                    attempts++;
                    setTimeout(checkAPIConfig, 100);
                }
            };
            
            checkAPIConfig();
        });
    }

    async loadChatHistory() {
        const user = await this.authManager.getCurrentUser();
        if (!user) return;

        try {
            // Get Supabase client from authManager
            const supabase = this.authManager.supabaseClient;
            
            const { data: chatData, error } = await supabase
                .from('chats')
                .select('messages')
                .eq('user_id', user.id)
                .single();

            if (error && error.code !== 'PGRST116') { // PGRST116 = no rows found
                throw error;
            }

            if (chatData?.messages) {
                chatData.messages.forEach(msg => this.displayMessage(msg.content, msg.isUser, false));
            }
        } catch (error) {
            console.error('Error loading chat history:', error);
        }
    }



    async sendMessage() {
        const message = this.messageInput.value.trim();
        if (!message) return;

        // Prevent multiple submissions
        if (this.sendButton && this.sendButton.disabled) return;

        // Check if API is configured
        if (this.apiKey === 'YOUR_TOGETHER_AI_API_KEY' || this.apiKey === 'YOUR_DEEPSEEK_API_KEY' || this.apiKey === 'YOUR_OPENAI_API_KEY' || !this.apiKey) {
            this.displayMessage(message, true);
            this.displayMessage('عذراً، لم يتم تكوين مفتاح API بعد. يرجى مراجعة ملف js/env-config.js وإضافة مفتاح API الخاص بك.', false);
            this.messageInput.value = '';
            return;
        }

        // Handle demo mode
        if (this.apiKey === 'DEMO_MODE') {
            this.handleDemoMode(message);
            return;
        }

        // Disable send button and show loading state
        if (this.sendButton) {
            this.sendButton.disabled = true;
            this.sendButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإرسال...';
        }

        try {
            // Verify hCaptcha before sending message
        const { hCaptchaManager } = await import('./hcaptcha.js');
        const token = await hCaptchaManager.executeHCaptcha('SEND_MESSAGE');
        
        if (!token || token === 'fallback-token') {
            console.warn('hCaptcha verification failed - continuing without protection');
        }
            
            // Clear input
            this.messageInput.value = '';
            
            // Display user message
            this.displayMessage(message, true);
            
            // Show loading indicator
            const loadingId = this.showLoadingMessage();
            
            try {
                // Get AI response
                const aiResponse = await this.getAIResponse(message);
                
                // Remove loading indicator
                this.removeLoadingMessage(loadingId);
                
                // Display AI response
                this.displayMessage(aiResponse, false);
                
                // Save to Supabase
                await this.saveChatMessage(message, aiResponse);
                
                // Reset button state on success
                if (this.sendButton) {
                    this.sendButton.disabled = false;
                    this.sendButton.innerHTML = 'إرسال';
                }
                
            } catch (error) {
                console.error('Error getting AI response:', error);
                this.removeLoadingMessage(loadingId);
                this.displayMessage('عذراً، حدث خطأ في الحصول على الرد. يرجى المحاولة مرة أخرى.', false);
                
                // Reset button state on error
                if (this.sendButton) {
                    this.sendButton.disabled = false;
                    this.sendButton.innerHTML = 'إرسال';
                }
            }
        } catch (captchaError) {
            console.error('hCaptcha verification failed:', captchaError);
            
            // Reset button state
            if (this.sendButton) {
                this.sendButton.disabled = false;
                this.sendButton.innerHTML = 'إرسال';
            }
            
            // Show appropriate error message
            if (captchaError.message === 'hCaptcha not loaded') {
                this.displayMessage('لم يتم تحميل نظام الأمان بعد. يرجى الانتظار قليلاً والمحاولة مرة أخرى.', false);
            } else {
                this.displayMessage('فشل في التحقق من الأمان. يرجى تحديث الصفحة والمحاولة مرة أخرى.', false);
            }
        }
    }

    async getAIResponse(userMessage) {
        // Check if API key is configured
        if (this.apiKey === 'YOUR_TOGETHER_AI_API_KEY' || this.apiKey === 'YOUR_DEEPSEEK_API_KEY' || this.apiKey === 'YOUR_OPENAI_API_KEY' || !this.apiKey) {
            return 'عذراً، لم يتم تكوين مفتاح API بعد. يرجى مراجعة ملف js/config.js وإضافة مفتاح API الخاص بك.';
        }

        try {
            const response = await fetch(this.apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: this.model,
                    messages: [
                        {
                            role: 'system',
                            content: this.systemPrompt
                        },
                        {
                            role: 'user',
                            content: userMessage
                        }
                    ],
                    max_tokens: this.maxTokens,
                    temperature: this.temperature
                })
            });

            if (!response.ok) {
                throw new Error(`API request failed: ${response.status}`);
            }

            const data = await response.json();
            return data.choices[0].message.content;
        } catch (error) {
            ErrorHandler.handleApiError(error);
            throw error;
        }
    }

    displayMessage(content, isUser, shouldSave = true) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'ai-message'} mb-4 p-3 rounded-lg max-w-[80%] ${isUser ? 'ml-auto bg-brand-burgundy text-white' : 'mr-auto glass-card text-slate-200'}`;
        messageDiv.textContent = content;
        
        this.chatContainer.appendChild(messageDiv);
        this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
    }

    showLoadingMessage() {
        const loadingDiv = document.createElement('div');
        const loadingId = 'loading-' + Date.now();
        loadingDiv.id = loadingId;
        loadingDiv.className = 'message ai-message mb-4 p-3 rounded-lg max-w-[80%] mr-auto glass-card text-slate-200';
        loadingDiv.innerHTML = '<div class="flex items-center gap-2"><div class="loading-dots">جاري التفكير</div><div class="animate-pulse">...</div></div>';
        
        this.chatContainer.appendChild(loadingDiv);
        this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
        
        return loadingId;
    }

    removeLoadingMessage(loadingId) {
        const loadingElement = document.getElementById(loadingId);
        if (loadingElement) {
            loadingElement.remove();
        }
    }

    async saveChatMessage(userMessage, aiResponse) {
        const user = await this.authManager.getCurrentUser();
        if (!user) return;

        try {
            const supabase = this.authManager.supabaseClient;
            
            const newMessages = [
                { content: userMessage, isUser: true, timestamp: new Date().toISOString() },
                { content: aiResponse, isUser: false, timestamp: new Date().toISOString() }
            ];

            // First, try to get existing chat
            const { data: existingChat, error: fetchError } = await supabase
                .from('chats')
                .select('messages')
                .eq('user_id', user.id)
                .single();

            if (fetchError && fetchError.code !== 'PGRST116') {
                throw fetchError;
            }

            if (existingChat) {
                // Update existing chat by appending new messages
                const updatedMessages = [...(existingChat.messages || []), ...newMessages];
                const { error: updateError } = await supabase
                    .from('chats')
                    .update({ messages: updatedMessages, updated_at: new Date().toISOString() })
                    .eq('user_id', user.id);
                
                if (updateError) throw updateError;
            } else {
                // Create new chat record
                const { error: insertError } = await supabase
                    .from('chats')
                    .insert({
                        user_id: user.id,
                        messages: newMessages,
                        created_at: new Date().toISOString(),
                        updated_at: new Date().toISOString()
                    });
                
                if (insertError) throw insertError;
            }
        } catch (error) {
            console.error('Error saving chat message:', error);
        }
    }

    async handleDemoMode(message) {
        // Clear input and display user message
        this.messageInput.value = '';
        this.displayMessage(message, true);
        
        // Disable send button and show loading state
        if (this.sendButton) {
            this.sendButton.disabled = true;
            this.sendButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإرسال...';
        }
        
        // Show loading indicator
        const loadingId = this.showLoadingMessage();
        
        // Simulate API delay
        setTimeout(() => {
            // Remove loading indicator
            this.removeLoadingMessage(loadingId);
            
            // Generate demo response
            const demoResponses = [
                'مرحباً! هذا وضع التجريب. لتفعيل الذكاء الاصطناعي الكامل، يرجى إضافة مفتاح API في ملف env-config.js',
                'شكراً لك على رسالتك! في الوضع التجريبي، يمكنني مساعدتك في فهم كيفية عمل النظام.',
                'أهلاً بك! هذا مثال على رد الذكاء الاصطناعي. للحصول على ردود حقيقية، يرجى تكوين API key.',
                'مرحباً! أنا في الوضع التجريبي حالياً. يمكنك تجربة إرسال رسائل مختلفة لرؤية كيف يعمل النظام.',
                'شكراً لتجربة النظام! هذا رد تجريبي. للحصول على مساعدة حقيقية في إنشاء المحتوى، يرجى إعداد API key.'
            ];
            
            const randomResponse = demoResponses[Math.floor(Math.random() * demoResponses.length)];
            this.displayMessage(randomResponse, false);
            
            // Reset button state
            if (this.sendButton) {
                this.sendButton.disabled = false;
                this.sendButton.innerHTML = 'إرسال';
            }
        }, 1500); // 1.5 second delay to simulate API call
    }
}

const chatManager = new ChatManager();

// Make it available globally
if (typeof window !== 'undefined') {
    window.chatManager = chatManager;
}