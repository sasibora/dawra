// Login System - OTP Authentication
import { authManager } from './auth.js';

// DOM Elements
let emailStep, otpStep, emailForm, otpForm;
let emailInput, otpInput, sendCodeBtn, verifyCodeBtn;
let sendCodeText, sendCodeLoading, verifyCodeText, verifyCodeLoading;
let backToEmailBtn, resendOtpBtn, messageDisplay;

// Current email for OTP verification
let currentEmail = '';

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Initialize auth manager
        await authManager.init();
        
        // Get DOM elements
        initializeElements();
        
        // Set up event listeners
        setupEventListeners();
        
        console.log('Login system initialized successfully');
    } catch (error) {
        console.error('Failed to initialize login system:', error);
        showMessage('خطأ في تهيئة النظام. يرجى إعادة تحميل الصفحة.', 'error');
    }
});

// Initialize DOM elements
function initializeElements() {
    // Steps
    emailStep = document.getElementById('email-step');
    otpStep = document.getElementById('otp-step');
    
    // Forms
    emailForm = document.getElementById('email-form');
    otpForm = document.getElementById('otp-form');
    
    // Inputs
    emailInput = document.getElementById('email-input');
    otpInput = document.getElementById('otp-code');
    
    // Buttons
    sendCodeBtn = document.getElementById('send-code-btn');
    verifyCodeBtn = document.getElementById('verify-code-btn');
    backToEmailBtn = document.getElementById('back-to-email');
    resendOtpBtn = document.getElementById('resend-otp');
    
    // Button text elements
    sendCodeText = document.getElementById('send-code-text');
    sendCodeLoading = document.getElementById('send-code-loading');
    verifyCodeText = document.getElementById('verify-code-text');
    verifyCodeLoading = document.getElementById('verify-code-loading');
    
    // Message display
    messageDisplay = document.getElementById('message-display');
    
    // Validate all elements exist
    const requiredElements = {
        emailStep, otpStep, emailForm, otpForm, emailInput, otpInput,
        sendCodeBtn, verifyCodeBtn, messageDisplay
    };
    
    for (const [name, element] of Object.entries(requiredElements)) {
        if (!element) {
            throw new Error(`Required element not found: ${name}`);
        }
    }
}

// Set up event listeners
function setupEventListeners() {
    // Email form submission
    emailForm.addEventListener('submit', handleEmailSubmit);
    
    // OTP form submission
    otpForm.addEventListener('submit', handleOtpSubmit);
    
    // Back to email button
    if (backToEmailBtn) {
        backToEmailBtn.addEventListener('click', showEmailStep);
    }
    
    // Resend OTP button
    if (resendOtpBtn) {
        resendOtpBtn.addEventListener('click', handleResendOtp);
    }
    
    // OTP input formatting
    if (otpInput) {
        otpInput.addEventListener('input', formatOtpInput);
        otpInput.addEventListener('paste', handleOtpPaste);
    }
    
    // Close modal button
    const closeBtn = document.getElementById('close-login-modal');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            window.location.href = 'index.html';
        });
    }
}

// Handle email form submission
async function handleEmailSubmit(e) {
    e.preventDefault();
    
    const email = emailInput.value.trim();
    
    // Validate email
    if (!email) {
        showMessage('يرجى إدخال البريد الإلكتروني', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showMessage('يرجى إدخال بريد إلكتروني صحيح', 'error');
        return;
    }
    
    // Show loading state
    setButtonLoading(sendCodeBtn, sendCodeText, sendCodeLoading, true);
    hideMessage();
    
    try {
        // Send OTP using auth manager
        const result = await authManager.sendOTP(email);
        
        if (result.success) {
            currentEmail = email;
            showMessage('تم إرسال رمز التحقق إلى بريدك الإلكتروني', 'success');
            showOtpStep();
        } else {
            showMessage(`خطأ في إرسال الرمز: ${result.error}`, 'error');
        }
    } catch (error) {
        console.error('Error sending OTP:', error);
        showMessage('خطأ في إرسال رمز التحقق. يرجى المحاولة مرة أخرى.', 'error');
    } finally {
        setButtonLoading(sendCodeBtn, sendCodeText, sendCodeLoading, false);
    }
}

// Handle OTP form submission
async function handleOtpSubmit(e) {
    e.preventDefault();
    
    const otpCode = otpInput.value.trim();
    
    // Validate OTP
    if (!otpCode) {
        showMessage('يرجى إدخال رمز التحقق', 'error');
        return;
    }
    
    if (otpCode.length !== 6) {
        showMessage('رمز التحقق يجب أن يكون مكون من 6 أرقام', 'error');
        return;
    }
    
    // Show loading state
    setButtonLoading(verifyCodeBtn, verifyCodeText, verifyCodeLoading, true);
    hideMessage();
    
    try {
        // Verify OTP using auth manager
        const result = await authManager.verifyOTP(currentEmail, otpCode);
        
        if (result.success) {
            showMessage('تم تسجيل الدخول بنجاح!', 'success');
            
            // Wait a moment then redirect
            setTimeout(() => {
                const urlParams = new URLSearchParams(window.location.search);
                const redirectUrl = urlParams.get('redirect') || 'dashboard.html';
                window.location.href = redirectUrl;
            }, 1500);
        } else {
            showMessage(`رمز التحقق غير صحيح: ${result.error}`, 'error');
            otpInput.value = '';
            otpInput.focus();
        }
    } catch (error) {
        console.error('Error verifying OTP:', error);
        showMessage('خطأ في التحقق من الرمز. يرجى المحاولة مرة أخرى.', 'error');
        otpInput.value = '';
        otpInput.focus();
    } finally {
        setButtonLoading(verifyCodeBtn, verifyCodeText, verifyCodeLoading, false);
    }
}

// Handle resend OTP
async function handleResendOtp() {
    if (!currentEmail) {
        showMessage('خطأ: لم يتم العثور على البريد الإلكتروني', 'error');
        return;
    }
    
    // Disable resend button temporarily
    resendOtpBtn.disabled = true;
    resendOtpBtn.textContent = 'جاري الإرسال...';
    
    try {
        const result = await authManager.sendOTP(currentEmail);
        
        if (result.success) {
            showMessage('تم إعادة إرسال رمز التحقق', 'success');
            otpInput.value = '';
            otpInput.focus();
        } else {
            showMessage(`خطأ في إعادة الإرسال: ${result.error}`, 'error');
        }
    } catch (error) {
        console.error('Error resending OTP:', error);
        showMessage('خطأ في إعادة إرسال الرمز', 'error');
    } finally {
        // Re-enable resend button after 30 seconds
        setTimeout(() => {
            resendOtpBtn.disabled = false;
            resendOtpBtn.textContent = 'إعادة الإرسال';
        }, 30000);
    }
}

// Show email step
function showEmailStep() {
    emailStep.classList.remove('hidden');
    otpStep.classList.add('hidden');
    emailInput.focus();
    hideMessage();
}

// Show OTP step
function showOtpStep() {
    emailStep.classList.add('hidden');
    otpStep.classList.remove('hidden');
    otpInput.focus();
}

// Format OTP input (numbers only)
function formatOtpInput(e) {
    let value = e.target.value.replace(/\D/g, ''); // Remove non-digits
    if (value.length > 6) {
        value = value.slice(0, 6); // Limit to 6 digits
    }
    e.target.value = value;
}

// Handle OTP paste
function handleOtpPaste(e) {
    e.preventDefault();
    const paste = (e.clipboardData || window.clipboardData).getData('text');
    const numbers = paste.replace(/\D/g, '').slice(0, 6);
    otpInput.value = numbers;
    
    if (numbers.length === 6) {
        // Auto-submit if 6 digits pasted
        setTimeout(() => otpForm.dispatchEvent(new Event('submit')), 100);
    }
}

// Set button loading state
function setButtonLoading(button, textElement, loadingElement, isLoading) {
    if (!button) return;
    
    button.disabled = isLoading;
    
    if (textElement && loadingElement) {
        if (isLoading) {
            textElement.classList.add('hidden');
            loadingElement.classList.remove('hidden');
        } else {
            textElement.classList.remove('hidden');
            loadingElement.classList.add('hidden');
        }
    }
}

// Show message
function showMessage(message, type = 'info') {
    if (!messageDisplay) return;
    
    messageDisplay.textContent = message;
    messageDisplay.className = `text-sm text-center mt-2 min-h-[20px] ${getMessageClass(type)}`;
    messageDisplay.classList.remove('hidden');
    
    // Auto-hide success messages after 5 seconds
    if (type === 'success') {
        setTimeout(hideMessage, 5000);
    }
}

// Hide message
function hideMessage() {
    if (messageDisplay) {
        messageDisplay.classList.add('hidden');
    }
}

// Get message CSS class based on type
function getMessageClass(type) {
    switch (type) {
        case 'error':
            return 'text-red-400';
        case 'success':
            return 'text-green-400';
        case 'warning':
            return 'text-yellow-400';
        default:
            return 'text-blue-400';
    }
}

// Validate email format
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Export for debugging
if (typeof window !== 'undefined') {
    window.loginSystem = {
        showEmailStep,
        showOtpStep,
        showMessage,
        hideMessage,
        currentEmail: () => currentEmail
    };
}