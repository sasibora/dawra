// Footer Component
class FooterComponent {
    constructor() {
        this.init();
    }

    init() {
        this.createFooter();
    }

    getBaseUrl() {
        // Get the current path and determine the base URL for navigation
        const currentPath = window.location.pathname;
        
        // Count the directory depth to determine how many '../' we need
        const pathParts = currentPath.split('/').filter(part => part !== '');
        const fileName = pathParts[pathParts.length - 1];
        
        // Remove the filename from the path parts to get directory depth
        if (fileName && fileName.includes('.html')) {
            pathParts.pop();
        }
        
        // Calculate relative path back to root
        const depth = pathParts.length;
        const relativePath = '../'.repeat(depth);
        
        return relativePath;
    }

    createFooter() {
        // Determine if we're on index.html or another page
        const isIndexPage = window.location.pathname === '/' || window.location.pathname.endsWith('/index.html') || window.location.pathname.endsWith('/newsite/') || window.location.pathname === '/newsite/index.html';
        const baseUrl = isIndexPage ? '' : this.getBaseUrl();
        
        const footerHTML = `
            <footer id="contact" class="glass-card-strong mt-24 py-8 border-t border-brand-gold/20">
                <div class="container mx-auto px-6">
                    <!-- Section 1: Main Footer Content -->
                    <div class="grid md:grid-cols-3 gap-8 mb-8">
                        <!-- Left Column: Brand & Social -->
                        <div class="space-y-4">
                            <div class="flex items-center gap-3 mb-4">
                                <img src="assets/images/logo.svg" alt="شعار الشارع المغربي" class="w-12 h-12 rounded-full border-2 border-brand-gold" loading="lazy" onerror="this.onerror=null;this.src='https://placehold.co/48x48/8B1538/ffffff?text=AI';">
                                <h3 class="text-xl font-bold text-brand-gold">الشارع المغربي</h3>
                            </div>
                            <p class="text-slate-400 text-sm leading-relaxed">نهدف إلى تمكين الشباب العربي من إتقان أحدث التقنيات الرقمية وتطوير مهاراتهم في مجال إنتاج المحتوى.</p>
                            <div class="flex gap-4 mt-4">
                                <a href="#" class="social-link text-slate-400">
                                    <i data-lucide="youtube" class="w-5 h-5"></i>
                                </a>
                                <a href="#" class="social-link text-slate-400">
                                    <i data-lucide="instagram" class="w-5 h-5"></i>
                                </a>
                                <a href="#" class="social-link text-slate-400">
                                    <i data-lucide="twitter" class="w-5 h-5"></i>
                                </a>
                                <a href="#" class="social-link text-slate-400">
                                    <i data-lucide="facebook" class="w-5 h-5"></i>
                                </a>
                            </div>
                        </div>
                        
                        <!-- Middle Column: Quick Links -->
                        <div class="space-y-4">
                            <h4 class="text-lg font-bold text-white">روابط سريعة</h4>
                            <div class="grid grid-cols-2 gap-x-6 gap-y-3">
                                <!-- Column 1 -->
                                <div class="space-y-3">
                                    <div class="flex items-center gap-3">
                                        <div class="w-5 h-5 flex items-center justify-center">
                                            <i data-lucide="home" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                        </div>
                                        <a href="${baseUrl}" class="footer-link text-slate-400 text-sm">الرئيسية</a>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <div class="w-5 h-5 flex items-center justify-center">
                                            <i data-lucide="bookmark" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                        </div>
                                        <a href="${baseUrl}pages/tools/backprompt.html" class="footer-link text-slate-400 text-sm">بنك الأوامر</a>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <div class="w-5 h-5 flex items-center justify-center">
                                            <i data-lucide="palette" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                        </div>
                                        <a href="${baseUrl}pages/tools/AIStyleBank.html" class="footer-link text-slate-400 text-sm">بنك الأنماط</a>
                                    </div>
                                </div>
                                <!-- Column 2 -->
                                <div class="space-y-3">
                                    <div class="flex items-center gap-3">
                                        <div class="w-5 h-5 flex items-center justify-center">
                                            <i data-lucide="wrench" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                        </div>
                                        <a href="${baseUrl}pages/tools/AIToolsDirectory.html" class="footer-link text-slate-400 text-sm">بنك الأدوات</a>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <div class="w-5 h-5 flex items-center justify-center">
                                            <i data-lucide="edit-3" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                        </div>
                                        <a href="${baseUrl}pages/tools/exercices.html" class="footer-link text-slate-400 text-sm">بنك التمارين</a>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <div class="w-5 h-5 flex items-center justify-center">
                                            <i data-lucide="video" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                        </div>
                                        <a href="${baseUrl}pages/tools/Aicoursevideos.html" class="footer-link text-slate-400 text-sm">تسجيلات الدورة</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Right Column: Contact Info -->
                        <div class="space-y-4">
                            <h4 class="text-lg font-bold text-white">معلومات الاتصال</h4>
                            <div class="space-y-3">
                                <div class="flex items-center gap-3">
                                    <div class="w-5 h-5 flex items-center justify-center">
                                        <i data-lucide="mail" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                    </div>
                                    <span class="text-slate-400 text-sm break-all">contact@dawra.live</span>
                                </div>
                                <div class="flex items-center gap-3">
                                    <div class="w-5 h-5 flex items-center justify-center">
                                        <i data-lucide="phone" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                    </div>
                                    <span class="text-slate-400 text-sm" dir="ltr">+1 (234) 279-7741</span>
                                </div>
                                <div class="flex items-center gap-3">
                                    <div class="w-5 h-5 flex items-center justify-center">
                                        <i data-lucide="map-pin" class="w-5 h-5 text-brand-gold flex-shrink-0"></i>
                                    </div>
                                    <span class="text-slate-400 text-sm">المغرب</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Section 2: Legal Pages (Horizontal with dots) -->
                    <div class="border-t border-slate-700 pt-6 pb-6">
                        <div class="flex justify-center items-center gap-2 text-slate-400 text-sm flex-wrap">
                            <a href="${baseUrl}pages/legal/privacy.html" class="footer-link">سياسة الخصوصية</a>
                            <span class="text-slate-600">•</span>
                            <a href="${baseUrl}pages/legal/terms.html" class="footer-link">شروط الاستخدام</a>
                            <span class="text-slate-600">•</span>
                            <a href="${baseUrl}pages/legal/refund.html" class="footer-link">سياسة الاسترداد</a>
                        </div>
                    </div>
                    
                    <!-- Section 3: Copyright -->
                    <div class="border-t border-slate-700 pt-6 text-center text-slate-400">
                        <p class="text-sm">صُنع بـ ❤️ من طرف <a href="https://dawra.live" target="_blank" class="gradient-text font-bold">الشارع المغربي</a> &copy; 2025. جميع الحقوق محفوظة.</p>
                    </div>
                </div>
            </footer>
        `;

        // Check if footer already exists and remove it
        const existingFooter = document.querySelector('footer');
        if (existingFooter) {
            existingFooter.remove();
        }

        // Add footer to the end of body
        document.body.insertAdjacentHTML('beforeend', footerHTML);
        
        // Initialize Lucide icons for the footer
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
}

// Initialize footer when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new FooterComponent();
    });
} else {
    new FooterComponent();
}