// API Configuration
// Configuration now uses environment variables for security

import { ENV_CONFIG } from './env-config.js';

export const API_CONFIG = {
    // AI API Configuration from environment
    apiKey: ENV_CONFIG.AI_API.apiKey,
    apiUrl: ENV_CONFIG.AI_API.apiUrl,
    model: ENV_CONFIG.AI_API.model,
    
    // Chat settings
    maxTokens: ENV_CONFIG.AI_API.maxTokens,
    temperature: ENV_CONFIG.AI_API.temperature,
    
    // System prompt for the AI assistant
    systemPrompt: `أنت مساعد ذكي متخصص في مساعدة منشئي المحتوى على وسائل التواصل الاجتماعي. 
    مهمتك هي:
    1. مساعدة المستخدمين في العصف الذهني للأفكار الإبداعية
    2. تقديم اقتراحات لتطوير المحتوى المرئي والمكتوب
    3. مساعدتهم في استخدام أدوات الذكاء الاصطناعي بفعالية
    4. تقديم نصائح عملية لتحسين جودة المحتوى
    
    أجب دائماً باللغة العربية وكن مفيداً وإبداعياً في إجاباتك.`
};

// Instructions for setup:
// 1. Sign up for an API account with your chosen provider
// 2. Get your API key from the provider's dashboard
// 3. Replace 'YOUR_API_KEY' above with your actual API key
// 4. Uncomment the configuration for your chosen provider
// 5. Comment out the other provider configurations