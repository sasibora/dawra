# Quick Setup Guide

## 🚀 Getting Started

### Step 1: Configure AI API
1. Open `js/config.js`
2. Choose your AI provider (Together AI, DeepSeek, or OpenAI)
3. Replace the API key with your actual key
4. Uncomment your chosen provider's configuration
5. Comment out the other providers

### Step 2: Firebase Setup
The Firebase configuration is already set up. Ensure:
- Firebase Authentication is enabled
- Firestore Database is enabled
- Security rules allow authenticated users to read/write their own data

### Step 3: Test the Application
1. Open `index.html` in a web browser
2. Click "ابدأ الآن" (Start Now)
3. Create a new account or sign in
4. You'll be redirected to the dashboard
5. Start chatting with the AI assistant

## 🔧 Configuration Options

### Supported AI Providers:
- **Together AI** (Recommended): Fast and cost-effective
- **DeepSeek**: Good Arabic language support
- **OpenAI**: High quality responses

### Firebase Collections:
- `chats/{userId}`: Stores user chat history
- `accessCodes/CodesList`: Existing access codes (keep as is)

## 🛠️ Troubleshooting

### Common Issues:
1. **API Key Error**: Check `js/config.js` for correct API key
2. **Authentication Issues**: Verify Firebase configuration
3. **Chat Not Loading**: Check browser console for errors
4. **Firestore Permissions**: Ensure security rules are properly set

### Security Rules for Firestore:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /chats/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /accessCodes/{document} {
      allow read: if request.auth != null;
    }
  }
}
```

## 📱 Features Included:
✅ User Authentication (Email/Password)
✅ Personal Dashboard
✅ AI Chat Interface
✅ Chat History Storage
✅ Responsive Design
✅ Arabic Language Support
✅ Integration with Existing Tools

## 🎯 Next Steps:
1. Customize the AI system prompt in `js/config.js`
2. Add more chat features as needed
3. Integrate with additional AI models
4. Enhance the user interface

For support, contact: contact@dawra.live